﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HastahaneProje
{
    class Sqlbaglantisi
    {
        public SqlConnection baglanti()
        {
            SqlConnection baglan  = new SqlConnection("Data Source=ARDACANUYSAA1BA;Initial Catalog=HastahaneProje;Integrated Security=True");
            baglan.Open();
            return baglan;
        }      
        //Database sql connecrtion ile bağlandi her kullanımda bu metodu çağırmak gerekecektir.
    }
}
