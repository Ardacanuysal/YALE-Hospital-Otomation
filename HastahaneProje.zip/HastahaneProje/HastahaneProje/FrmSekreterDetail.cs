﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HastahaneProje
{
    public partial class FrmSekreterDetail : Form
    {
        public FrmSekreterDetail()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }
        public String TcNumara;
        Sqlbaglantisi bgl = new Sqlbaglantisi();
        private void FrmSekreterDetail_Load(object sender, EventArgs e)
        {
            //Tc Sekreter detaya label olarak alma 
            lblTc.Text = TcNumara;

            //Ad Soyad Çekme
            SqlCommand komut1 = new SqlCommand("SELECT SekreterAdSoyad FROM Tbl_sekreter3 WHERE SekreterTc=@p1",bgl.baglanti());
            komut1.Parameters.AddWithValue("@p1", lblTc.Text);
            SqlDataReader dr = komut1.ExecuteReader();
            while (dr.Read())
            {
                lblAdsoyad.Text = dr[0].ToString();
            }
            bgl.baglanti().Close();

            //Branşları Datagride Aktarma
            DataTable dt1 = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("SELECT bransAd FROM Tbl_Brans4",bgl.baglanti());
            da.Fill(dt1);
            dataGridView1.DataSource = dt1;
         
        }
        private void button6_Click(object sender, EventArgs e)
        {

        }
        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
